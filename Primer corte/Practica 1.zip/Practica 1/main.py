# 1. Importar las clases
from activity_1 import ListPractice
from activity_2 import Activity2

# 2. Crear las instancias para ejecutar metodo inicializador de las clases
inst_list_practice= ListPractice()
inst_activity2= Activity2()

#3. Acceder mediante la instancia de la clase a los métodos
inst_list_practice.show_info_list()
inst_list_practice.input_data_courses()

