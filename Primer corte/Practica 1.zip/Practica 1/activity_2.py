"""_Activity 2
"""
class Activity2:
    def __init__(self):
        self.user_status= "ACTIVE"
        
