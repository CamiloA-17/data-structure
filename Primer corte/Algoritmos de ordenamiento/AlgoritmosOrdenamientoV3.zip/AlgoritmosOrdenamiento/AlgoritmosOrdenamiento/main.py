from sort_algorithms import SortAlgorithms
inst_sort_algorithms = SortAlgorithms()

#inst_sort_algorithms.bubble_sort_function()
#inst_sort_algorithms.bubble_sort_function_refactor()
#inst_sort_algorithms.select_sort_function()
#inst_sort_algorithms.insert_sort_function_v2()
inst_sort_algorithms.test_merge_sort_function(inst_sort_algorithms.list_merge_sort)
#print(inst_sort_algorithms.quick_sort_function(inst_sort_algorithms.list_quick_sort))
#print(inst_sort_algorithms.list_radix_sort)
#inst_sort_algorithms.radixSort(inst_sort_algorithms.list_radix_sort)
#print(inst_sort_algorithms.list_radix_sort)